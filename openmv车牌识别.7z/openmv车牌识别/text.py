import sensor
from image import ImageIO
from sensor import alloc_extra_fb,BINARY,set_framebuffers,TRIPLE_BUFFER

font = alloc_extra_fb(2048,1192,BINARY)
stream = ImageIO('/font/font_by_CHH.bin', "r")
font_img = stream.read(copy_to_fb=True)
stream.close()
font.draw_image(font_img,0,0)
set_framebuffers(TRIPLE_BUFFER)
